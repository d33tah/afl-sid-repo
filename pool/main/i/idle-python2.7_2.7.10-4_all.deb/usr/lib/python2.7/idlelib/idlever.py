"""Unused by Idle: there is no separate Idle version anymore.
Kept only for possible existing extension use."""
from sys import version
IDLE_VERSION = version[:version.index(' ')]
