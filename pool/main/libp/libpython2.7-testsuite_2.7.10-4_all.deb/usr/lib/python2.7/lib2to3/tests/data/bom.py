﻿# coding: utf-8
print "BOM BOOM!"
